import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:spiral_trade_show/common/info_shelf/domain/info_shelf_repository.dart';
import 'package:spiral_trade_show/common/info_shelf/domain/info_shelf_state.dart';

class InfoShelfCubit extends Cubit<InfoShelfState> {
  final InfoShelfRepository repository;

  InfoShelfCubit(super.initialState, this.repository);

  Future<void> fetchInfoList(
    int startIndex,
    int endIndex,
  ) async {
    try {
      final response = await repository.fetchInfo(
        startIndex,
        endIndex,
      );

      emit(state.copyWith(
        status: InfoShelfStatus.success,
        info: response,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: InfoShelfStatus.failure,
      ));
    }
  }

  Future<void> initialLoadInfoList() async {
    try {
      final response = await repository.fetchInfo(
        0,
        30,
      );

      emit(state.copyWith(
        status: InfoShelfStatus.success,
        info: response,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: InfoShelfStatus.failure,
      ));
    }
  }
}
