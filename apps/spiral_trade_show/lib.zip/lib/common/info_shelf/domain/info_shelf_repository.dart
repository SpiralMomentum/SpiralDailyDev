import 'package:spiral_trade_show/common/info_shelf/domain/entity/info.dart';

abstract class InfoShelfRepository {
  Future<List<Info>> fetchInfo(
    int startIndex,
    int endIndex,
  );
}
